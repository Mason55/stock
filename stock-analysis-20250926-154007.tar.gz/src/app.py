# src/app.py - Flask application main entry point
import logging
from flask import Flask
from flask_cors import CORS
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from config.settings import settings
from src.models.stock import Base
from src.api.stock_api import stock_bp
import src.api.stock_api as stock_api_module

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def create_app():
    """Application factory"""
    app = Flask(__name__)
    
    # Enable CORS for frontend
    CORS(app, origins=['http://localhost:3000', 'http://127.0.0.1:3000'])
    
    # Database setup
    engine = create_engine(settings.DATABASE_URL, echo=settings.DEBUG)
    Base.metadata.create_all(engine)
    
    Session = sessionmaker(bind=engine)
    db_session = Session()
    
    # Inject database session into API module
    stock_api_module.db_session = db_session
    
    # Register blueprints
    app.register_blueprint(stock_bp)
    
    # Root endpoint
    @app.route('/')
    def index():
        return {
            'message': 'Chinese Stock Analysis System API',
            'version': '1.0.0',
            'endpoints': {
                'stocks': '/api/stocks',
                'health': '/api/stocks/health',
                'docs': 'https://github.com/your-org/stock-analysis-system'
            }
        }
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        return {'error': 'Resource not found'}, 404
    
    @app.errorhandler(500)
    def internal_error(error):
        return {'error': 'Internal server error'}, 500
    
    logger.info("Stock Analysis System started successfully")
    return app


if __name__ == '__main__':
    app = create_app()
    app.run(
        host=settings.API_HOST,
        port=settings.API_PORT,
        debug=settings.DEBUG
    )