# 中国股市股票信息查询与投资建议系统

基于机器学习的中国A股实时行情分析与投资建议系统，提供股票查询、技术分析、投资建议和风险评估功能。

## 核心功能

- **实时行情展示**: 股价、涨跌幅、成交量、五档盘口数据
- **基本面分析**: 财务指标、估值分析、同比趋势
- **技术指标分析**: MA、RSI、MACD、布林带等技术指标
- **ML投资建议**: 基于多因子模型的买入/观望/回避建议
- **因子解释**: SHAP值驱动的可解释性分析
- **股票筛选**: 多条件组合筛选和策略回测
- **风险预警**: ST风险、财务异常、极端波动预警

## 技术架构

```
[数据源] → [采集层] → [处理层] → [存储层] → [模型层] → [API层] → [前端]
```

### 后端技术栈
- **Python 3.11** + Flask: API服务
- **PostgreSQL**: 关系数据存储
- **Redis**: 缓存和会话存储
- **Apache Kafka**: 实时数据流处理
- **Scikit-learn/XGBoost**: 机器学习模型
- **SHAP**: 模型可解释性分析

### 前端技术栈
- **原生JavaScript**: 交互逻辑
- **Chart.js**: 数据可视化
- **CSS Grid/Flexbox**: 响应式布局
- **FontAwesome**: 图标库

## 快速开始

### 使用Docker部署（推荐）

```bash
# 克隆项目
git clone <repository-url>
cd stock-analysis-system

# 配置环境变量
cp .env.example .env
# 编辑 .env 文件配置数据库和API密钥

# 启动所有服务
docker-compose up -d

# 查看服务状态
docker-compose ps

# 访问应用
open http://localhost:5000
```

### 本地开发环境

```bash
# 创建虚拟环境
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 安装依赖
pip install -r requirements.txt

# 启动数据库（需要PostgreSQL和Redis）
# 参考docker-compose.yml配置

# 运行应用
python src/app.py

# 打开浏览器访问前端
open frontend/index.html
```

## API文档

### 股票查询
```http
GET /api/stocks/{stock_code}
```
获取股票基本信息、最新价格和投资建议

### 历史数据
```http
GET /api/stocks/{stock_code}/timeline?range=1M
```
支持范围: 1D, 1W, 1M, 3M, YTD, 1Y

### 因子分析
```http
GET /api/stocks/{stock_code}/factors
```
获取技术指标和因子得分

### 股票筛选
```http
GET /api/stocks/scan?industry=银行&min_price=10&action=buy
```

### 生成建议
```http
POST /api/stocks/recommend/{stock_code}
```

## 配置说明

### 数据源配置
```python
# config/settings.py
STOCK_DATA_API_KEY = "your_api_key"
STOCK_DATA_BASE_URL = "https://api.provider.com"
```

### 模型参数
```python
MODEL_UPDATE_INTERVAL = 3600  # 模型更新频率(秒)
CACHE_TTL = 300              # 缓存过期时间(秒)
API_TIMEOUT = 1.5            # API超时时间(秒)
```

## 系统监控

### 健康检查
```bash
curl http://localhost:5000/api/stocks/health
```

### 日志查看
```bash
docker-compose logs -f app
```

### 性能监控
- API响应时间 P95 < 1.5秒
- 批量筛选1000只股票 < 5秒  
- 系统可用性 > 99.5%

## 开发指南

### 添加新的技术指标
1. 在 `src/services/recommendation_engine.py` 的 `calculate_technical_indicators` 方法中添加指标计算
2. 在 `extract_features` 方法中提取特征值
3. 更新前端 `getFactorDisplayName` 方法添加显示名称

### 扩展数据源
1. 在 `src/services/data_collector.py` 中实现新的数据采集方法
2. 更新数据模型 `src/models/stock.py` 
3. 添加相应的API端点

### 模型优化
- 特征工程在 `RecommendationEngine.extract_features()`
- 模型训练在 `RecommendationEngine.train_model()`
- 超参数调优建议使用Grid Search或贝叶斯优化

## 部署指南

### 生产环境部署
```bash
# 生产环境配置
export DEBUG=False
export API_HOST=0.0.0.0
export DATABASE_URL=postgresql://user:pass@prod-db:5432/stockdb

# 使用Gunicorn启动
gunicorn --bind 0.0.0.0:5000 --workers 4 src.app:create_app()
```

### 数据库迁移
```bash
# 初始化数据库表
python -c "from src.app import create_app; create_app()"
```

## 风险声明

本系统提供的投资建议仅供参考，不构成投资建议。投资有风险，入市需谨慎。系统预测准确性无法保证，使用者应结合自身情况做出投资决策。

## 许可证

MIT License - 详见 LICENSE 文件

## 贡献指南

1. Fork 项目
2. 创建功能分支 (`git checkout -b feature/amazing-feature`)
3. 提交更改 (`git commit -m 'Add amazing feature'`)
4. 推送到分支 (`git push origin feature/amazing-feature`)
5. 开启 Pull Request

## 支持

- Issues: 通过GitHub Issues报告bug或请求功能
- 文档: 查看项目Wiki了解详细文档  
- 讨论: 使用GitHub Discussions进行技术交流